import java.util.ArrayList;

/**
 * Application class for Assignment 1, Question 1, compsci215 2013
 * 
 * @author dber021
 *
 */
public class Question1 {

	public static void main(String[] args) {
		// Process command line arguments
		// read the file
		
		
		JobFinishEvent callback = new JobFinishEvent() {
			@Override
			public void onFinish(Job j) {
				// this will be called when a job is finished.				
			}
		};
		
		
		/*// example job addition:
		ArrayList<Job> jobs = new ArrayList<Job>();
		jobs.add(new Job(1, 0, 2, callback));
		jobs.add(new Job(2, 1, 3, callback));
		FirstComeFirstServed fcfs = new FirstComeFirstServed(jobs);
		fcfs.run();
		*/
	}

}
