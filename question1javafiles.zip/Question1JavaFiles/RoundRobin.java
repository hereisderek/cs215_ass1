import java.util.ArrayList;


public class RoundRobin extends AllocationStrategy {

	public RoundRobin(ArrayList<Job> jobs) {
		super(jobs);
	}

	@Override
	public void run() {

	}

}
