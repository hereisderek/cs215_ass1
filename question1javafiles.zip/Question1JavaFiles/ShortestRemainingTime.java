import java.util.ArrayList;


public class ShortestRemainingTime extends AllocationStrategy {

	public ShortestRemainingTime(ArrayList<Job> jobs) {
		super(jobs);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
