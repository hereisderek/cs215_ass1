README:

You have to implement the main method in Question1.java

You also need to implement the code in the JobFinishEvent.java (anonymous class in Question1 main)

You need to implement the run methods in FirstComeFirstServed RoundRobin and ShortestRemainingTime.