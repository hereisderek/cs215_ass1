import java.util.ArrayList;


public class FirstComeFirstServed extends AllocationStrategy {

	public FirstComeFirstServed(ArrayList<Job> jobs) {
		super(jobs);
	}

	@Override
	public void run() {

	}

}
