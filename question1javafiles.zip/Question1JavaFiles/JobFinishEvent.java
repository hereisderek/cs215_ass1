
public interface JobFinishEvent {
	public void onFinish(Job j);
}
